from django.apps import AppConfig


class CricketConfig(AppConfig):
    name = 'cricket'
